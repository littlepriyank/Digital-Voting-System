import time
import tkinter as tk
from tkinter import messagebox,simpledialog
import sqlite3
dbPath="C:\\VotingSystem\\voting_sys"
conn=sqlite3.connect(dbPath)
cur =conn.cursor()
qry1 = "select * from voter where voter_id =?" 
qry2 = "insert into voted values(?)"
qry3 = "select * from voted where v_id =?" 
qry4 = "delete from voted" 
qry5 = "select * from admin where pswd = ?"
qry6 = "update voter set voted = 1 where voter_id = ?"
def func4():
	conn.execute(qry4)
	try:
		conn.commit()
	except:
		conn.rollback()
	from vote_here import func3
	func3()
def func1():
	def funcvv():
		evm.withdraw()
		from vote_here import func2
		func2()
		evm.deiconify()
	func4()
	evm=tk.Toplevel()
	def passs():
		pass
	evm.protocol("WM_DELETE_WINDOW",passs)
	def click1():
		psw=tk.simpledialog.askstring("Password required","enter password")
		if(psw!=None):	
			cur.execute(qry5,[psw])
			data = cur.fetchall()
			if(len(data)>=1):
				evm.quit()
			else:
				tk.messagebox.showerror("invalid","wrong password")
	def click():
		cur.execute(qry1,[e1.get()])
		data = cur.fetchall()
		if(len(data)==1):
			cur.execute(qry3,[e1.get()])
			d1= cur.fetchall()
			if(len(d1)>0):
				tk.messagebox.showerror("extra attempt","you can vote only one time")
			else:
				cur.execute(qry6,[e1.get()])
				cur.execute(qry2,[e1.get()])
				try:
					conn.commit()
				except:
					conn.rollback()
				funcvv()
		else:
			tk.messagebox.showerror("wrong","AADHAAR No.")
	e1 = tk.IntVar() 
	evm.title("E-voting")
	evm.iconbitmap('icon1.ico')
	evm.geometry("+500+250")
	evm.resizable(False,False)
	background_image=tk.PhotoImage(file = "bg1.gif")
	background_label = tk.Label(evm, image=background_image)
	background_label.place(x=0, y=0, relwidth=1, relheight=1)
	x=tk.Label(evm,text="VOTER",bg="bisque2",font=('arial',14)).pack(fill = tk.X,pady = 10)
	l= tk.Label(evm,text="Enter your Aadhaar No.:",bg="thistle4",font=('arial',10,'bold')).pack(pady =10)
	e = tk.Entry(evm,textvariable = e1,width = 20,bg = "thistle2",font = ('arial',15,'bold')).pack(padx=20,pady = 2,fill = tk.X)
	b = tk.Button(evm,text = "Vote", width = 10,bg = "ivory2",command = click,font=('arial',10,'bold')).pack(pady =10)
	ex = tk.Button(evm,text = "Exit",width = 10,bg = "ivory2",command = click1,font=('arial',10,'bold')).pack(pady = 5)
	evm.mainloop()	
	evm.destroy()
	return