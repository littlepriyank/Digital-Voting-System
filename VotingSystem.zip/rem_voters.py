from tkinter import *
import sqlite3
from tkinter import messagebox
import re
dbPath="C:\\VotingSystem\\voting_sys"
conx2=sqlite3.connect(dbPath)
curx2 =conx2.cursor()


def T_Vo():
	def exit(*args):
		master.destroy()
	curx2.execute("select * from voter where voted = 1")
	data = curx2.fetchall()
	if(len(data)>0):
		master = Toplevel(bg="dodgerblue4")
		l1= Label(master,text = "Today's Voters",bg="dodgerblue4",font = ('arial',15,'bold')).grid(row = 0,padx=40,pady = 10)
		listbox = Listbox(master, width=60,font =  'consolas',bg= "cornsilk4")
		listbox.grid(row = 1)
		listbox.insert(END, "{:<5s}  {:>15s}".format("Id","Name") )
		for i  in range(len(data)):
				item = "{:<5d}  {:>15s}".format(data[i][0],data[i][1])
				listbox.insert(END, item)
		master.bind("<Return>",exit)		
	else:
		messagebox.showerror("Empty","no one has voted yet")	
	
		
def r_vo():
	def exit(*args):
		master.destroy()
	curx2.execute("select * from voter where voted =0")
	data = curx2.fetchall()
	if(len(data)>0):	
		master = Toplevel(bg = "dodgerblue4")
		l1= Label(master,text = "Remaining Voters",bg = "dodgerblue4",font = ('arial',15,'bold')).grid(row = 0,padx=40,pady = 10)
		listbox = Listbox(master, width=60,font =  'consolas',bg= "cornsilk4")
		listbox.grid(row = 1)
		listbox.insert(END, "{:<5s}  {:>15s}".format("Id","Name") )
		for i  in range(len(data)):
				item = "{:<5d}  {:>15s}".format(data[i][0],data[i][1])
				listbox.insert(END, item)
		master.bind("<Return>",exit)			
	else:
		messagebox.showerror("Empty","all voters have given their vote")
	