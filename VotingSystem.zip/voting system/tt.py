import time
import tkinter as tk
evm = tk.Tk()
c=-1
s=[]
b=[]
def buttonclick7():
	global c
	c+=1
	s[0].value=tk.Label(evm,text="sadj",width =20,font=('arial',20,'bold'))
	s[c].grid(row=c,column=0,sticky="W")
	b[c]=tk.Button(evm,pady = 3,bd=3,width=20,fg="black",font=("arial",20,"bold"),text=" M.S.Yadav",bg="misty rose")
	b[c].grid(row=c,column=3,sticky="E")
def ds():
	global c
	s[c].destroy()
	b[c].destroy()
	
tk.Button(evm,text = "add",width = 20,command=buttonclick7).grid(row = 9)
tk.Button(evm,text = "add",width = 20,command=ds).grid(row = 9,column = 1)	
evm.mainloop()