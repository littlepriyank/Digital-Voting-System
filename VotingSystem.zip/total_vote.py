import tkinter as tk
import sqlite3
dbPath="C:\\VotingSystem\\voting_sys"
con4=sqlite3.connect(dbPath)
qry14="select vote from party where Party=?"
qry24="select sum(vote) from party"
qry34="select Party,max(vote) from party"
qry44 = "select Party,max(vote) from party where Party!= ? "
qry54 = "select Party from party where vote = ?"
qry64 = "select count(voter_id) from voter"
def func1():
	p1="Bhartiya Janta Party"
	p2="Indian National Congress"
	p3="Bhaujan Samaj Party"
	p4="Aam Adami Party"
	p5="Nationalist congress party"
	p6="Communist Party of India"
	p7="Samajwadi Party"
	p8 = "None of the above"

	def passs():
		pass
	
	evm_login=tk.Toplevel()
	evm_login.iconbitmap('icon1.ico')
	evm_login.geometry("+150+30")
	evm_login.resizable(False,False)
	background_image=tk.PhotoImage(file = "bg3.gif")
	background_label = tk.Label(evm_login, image=background_image)
	background_label.place(x=0, y=0, relwidth=1, relheight=1)
	evm_login.title("welcome to E-voting login")
	evm_login.protocol("WM_DELETE_WINDOW",passs)
	deli = 100
	svar = tk.StringVar()
	tvar = tk.StringVar()
	labl = tk.Label(evm_login,width = 30, textvariable=svar,font = ('arial',25,'bold'))

	def shif():
		shif.msg = shif.msg[1:] + shif.msg[0]
		svar.set(shif.msg)
		evm_login.after(deli, shif)


	def buttonclick8():
		 text_input.set("")
		 c=con4.execute(qry14,[p1])
		 for row in c:
				  r=row[0]
		 try:
				  con4.commit()
		 except:
				  con4.rollback()
		 text_input.set(r)
		
	def buttonclick9():
		 text_input.set("")
		 c=con4.execute(qry14,[p2])
		 for row in c:
				  r=row[0]
		 try:
				  con4.commit()
		 except:
				  con4.rollback()
		 text_input.set(r)
	   
	def buttonclick10():
		 text_input.set("")
		 c=con4.execute(qry14,[p3])
		 for row in c:
				  r=row[0]
		 try:
				  con4.commit()
		 except:
				  con4.rollback()
		 text_input.set(r)
	 
	def buttonclick11():
		 text_input.set("")
		 c=con4.execute(qry14,[p4])
		 for row in c:
				  r=row[0]
		 try:
				  con4.commit()
		 except:
				  con4.rollback()
		 text_input.set(r)
		 
	def buttonclick12():
		 text_input.set("")
		 c=con4.execute(qry14,[p5])
		 for row in c:
				  r=row[0]
		 try:
				  con4.commit()
		 except:
				  con4.rollback()
		 text_input.set(r)
		
	def buttonclick13():
		 text_input.set("")
		 c=con4.execute(qry14,[p6])
		 for row in c:
				  r=row[0]
		 try:
				  con4.commit()
		 except:
				  con4.rollback()
		 text_input.set(r)
		 
	def buttonclick14():
		 text_input.set("")
		 c=con4.execute(qry14,[p7])
		 for row in c:
				  r=row[0]
		 try:
				  con4.commit()
		 except:
				  con4.rollback()
		 text_input.set(r)  
	
	def buttonclick15():
		 text_input.set("")
		 c=con4.execute(qry14,[p8])
		 for row in c:
				  r=row[0]
		 try:
				  con4.commit()
		 except:
				  con4.rollback()
		 text_input.set(r)  
	
	def per():
		c=con4.execute(qry24)
		for j in c:
			v = j[0]
		w = con4.execute(qry64)
		for i in w:
			u = i[0]
		p = (v/u)*100
		text_input.set(p) 
	
	def exit(*args):
		evm_login.quit()
	
	def totalvote():
		 text_input.set("")
		 c=con4.execute(qry24)
		 for row in c:
				  r = row[0]
		 try:
				  con4.commit()
		 except:
				  con4.rollback()
		 text_input.set(r)

	#def w_party():
	#text_input.set("")


	c=con4.execute(qry34)
	for row in c:
		q = row[0]	
		x=row[1]
	t = con4.execute(qry54,[x])
	dat = t.fetchall()	
	if(len(dat)==1):	
		d=con4.execute(qry44,[row[0]])		
		for row1 in d:
			s = row1[0]
			y=row1[1]
		shif.msg = q+" win by "+ str(x-y) +" votes.     "
	else:
		shif.msg = "More than one party have maximum no. of votes.   "
	shif()
	labl.grid(row = 0,columnspan = 3,pady = 5)

	text_input=tk.StringVar()
	text_display=tk.Label(evm_login,text_input.set(""),width = "20",font=("arial",15,"bold"),textvariable=text_input,bd=10,bg="green").grid(row=11,column = 1,padx = 70,sticky = "W")         
	tk.Label(evm_login,text=p1,width = 20,font=('arial',20,"bold")).grid(row=2,column=0,sticky="W")
	btn1=tk.Button(evm_login,width = 15,padx=10,bd=3,fg="gray",font=("arial",20,"bold"),text="Total Votes",bg="white",command=lambda:buttonclick8()).grid(row=2,column=2,sticky="E")

	tk.Label(evm_login,text=p2,width = 20,font=('arial',20,"bold")).grid(row=3,column=0,sticky="W")
	btn2=tk.Button(evm_login,width = 15,padx=10,bd=3,fg="gray",font=("arial",20,"bold"),text="Total Votes",bg="white",command=lambda:buttonclick9()).grid(row=3,column=2,sticky="E")

	tk.Label(evm_login,text=p3,width = 20,font=('arial',20,'bold')).grid(row=4,column=0,sticky="W")      
	btn3=tk.Button(evm_login,width = 15,padx=10,bd=3,fg="gray",font=("arial",20,"bold"),text="Total Votes",bg="white",command=lambda:buttonclick10()).grid(row=4,column=2,sticky="E")                                                                                                                                   

	tk.Label(evm_login,text=p4,width = 20,font=('arial',20,'bold')).grid(row=5,column=0,sticky="W")   
	btn4=tk.Button(evm_login,width = 15,padx=10,bd=3,fg="gray",font=("arial",20,"bold"),text="Total Votes",bg="white",command=lambda:buttonclick11()).grid(row=5,column=2,sticky="E")

	tk.Label(evm_login,text=p5,width = 20,font=('arial',20,'bold')).grid(row=6,column=0,sticky="W")    
	btn5=tk.Button(evm_login,width = 15,padx=10,bd=3,fg="gray",font=("arial",20,"bold"),text="Total Votes",bg="white",command=lambda:buttonclick12()).grid(row=6,column=2,sticky="E")

	tk.Label(evm_login,text=p6,width = 20,font=('arial',20,'bold')).grid(row=7,column=0,sticky="W")
	btn6=tk.Button(evm_login,padx=10,bd=3,fg="gray",width = 15,font=("arial",20,"bold"),text="Total Votes",bg="white",command=lambda:buttonclick13()).grid(row=7,column=2,sticky="E")

	tk.Label(evm_login,text=p7,width = 20,font=('arial',20,'bold')).grid(row=8,column=0,sticky="W")
	btn7=tk.Button(evm_login,width = 15,padx=10,bd=3,fg="gray",font=("arial",20,"bold"),text="Total Votes",bg="white",command=lambda:buttonclick14()).grid(row=8,column=2,sticky="E")


	btn8=tk.Button(evm_login,width = 15,padx=10,bd=3,fg="gray",font=("arial",20,"bold"),text="Total Votes",bg="white",command=lambda:buttonclick15()).grid(row=9,column=2,sticky="E" )
	tk.Label(evm_login,text=p8,width = 20,font=('arial',20,'bold')).grid(row=9,column=0,sticky="W")

	btn9=tk.Button(evm_login,width = 15,padx=10,bd=3,fg="gray",font=("arial",20,"bold"),text="Overall Votes",bg="white",command=lambda:totalvote()).grid(row=10,column=2,sticky="E" )

	
	btn10=tk.Button(evm_login,width = 15,padx=10,bd=3,fg="gray",font=("arial",20,"bold"),text="Vote Percentage",bg="white",command=lambda:per()).grid(row=10,column=0,sticky="w" )
	evm_login.bind("<Return>",exit)
	evm_login.mainloop()
	evm_login.destroy()
	return
