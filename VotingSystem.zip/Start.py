import time
import re
import tkinter as tk
from tkinter import messagebox
import sqlite3
dbPath1="C:\\VotingSystem\\voting_sys"
con1=sqlite3.connect(dbPath1)
try:
	con1.execute("drop table admin")
	con1.execute("drop table party")
	con1.execute("drop table voter")
	con1.execute("drop table voted")
except:
		pass
try:
	con1.commit()
except:
		con1.rollback()
con1.execute("CREATE TABLE [admin] ([admin_id] INT(10) NOT NULL, [pswd] VARCHAR(10) NOT NULL)")
con1.execute("insert into admin values(151500,'123@vote')")
con1.execute("CREATE TABLE [party] ([Party] CHAR(30) NOT NULL ON CONFLICT ROLLBACK, [vote] INT(3))") 
con1.execute("CREATE TABLE [voter] ([voter_id] INT(12) NOT NULL ON CONFLICT ROLLBACK CONSTRAINT [primary key] UNIQUE ON CONFLICT ROLLBACK, [name] CHAR(20) NOT NULL, [voted] INT(1) NOT NULL ON CONFLICT REPLACE DEFAULT 0);") 
con1.execute("Insert into [voter] values(151500374,'Priyank',0)")
con1.execute("Insert into [voter] values(151500372,'Priyam',0)")
con1.execute("Insert into [voter] values(151500207,'Gauri',0)")
con1.execute("Insert into [voter] values(151500093,'Ankit',0)")
con1.execute("Insert into [voter] values(151500191,'Divya',0)")
con1.execute("Insert into [voter] values(151500179,'Deepansha',0)")
con1.execute("CREATE TABLE [voted] ([v_id] INT(5) NOT NULL ON CONFLICT ROLLBACK CONSTRAINT [p1] REFERENCES [voter]([voter_id]) ON DELETE SET NULL ON UPDATE CASCADE MATCH FULL);") 
try:
	con1.commit()
except:
		con1.rollback()
cur1 =con1.cursor()
qryl = "select * from admin where admin_id =? and pswd = ?" 	
def log_func(*args):
	ID = el1.get()	
	matchobj = re.match(r'^(\d){5,10}$',ID)
	if(matchobj):
		cur1.execute(qryl,[int(el1.get()),el2.get()])
		data = cur1.fetchall()
		if(len(data)==1):
			login.withdraw()
			from menu import option_func
			option_func()
			login.destroy()
		else:
			tk.messagebox.showerror("Not admin","wrong id or pswd")
	else:
		tk.messagebox.showerror("wrong","not a valid id")
def exit():
	login.destroy()			  
def passs():
	pass		
login=tk.Tk()
login.protocol("WM_DELETE_WINDOW",passs)
login.title("Voting System")
login.iconbitmap('icon1.ico')
login.geometry("+500+250")
login.resizable(False,False)
background_image=tk.PhotoImage(file = "bg1.gif")
background_label = tk.Label(login, image=background_image)
background_label.place(x=0, y=0, relwidth=1, relheight=1)
el1 = tk.StringVar()
el2 = tk.StringVar()
l1 = tk.Label(login,text = "Enter admin's ID",font = ('arial',10,'bold')).grid(row = 1,column = 0,sticky = "W",pady = 20,padx = 10)
admin_id = tk.Entry(login,textvariable = el1,width = 20,font = ('arial',10,'bold')).grid( row = 1,column  = 1,columnspan = 2,padx = 20,sticky = "E")
l2 = tk.Label(login,text = "Enter password",font = ('arial',10,'bold')).grid(row = 2,column = 0,sticky = "W",padx = 10)
pswd = tk.Entry(login,show = "*",textvariable = el2,width = 20,font = ('arial',10,'bold')).grid( row = 2,column = 1,columnspan = 2,padx = 20 ,sticky = "E")	
b = tk.Button(login,text = "Login",font = ('arial','10','bold'),bd = 5,width = 10,command = log_func).grid(row = 3,column = 0,padx= 10,pady = 20,sticky = "E")	
b2 = tk.Button(login,text = "Exit",font = ('arial','10','bold'),bd = 5,default="normal",width = 10,command = exit).grid(row = 3,column = 1,padx = 10,pady =5,sticky = "E")
login.bind("<Return>",log_func)
login.mainloop()
