import tkinter as tk
import sqlite3
dbPath="C:\\VotingSystem\\voting_sys"
conx1=sqlite3.connect(dbPath)
curx1 =conx1.cursor()
def option_func():
	conx1.execute("update voter set voted = 0")
	try:
		conx1.commit()
	except:
		conx1.rollback()
	option=tk.Toplevel()
	option.title("Voting System")
	option.iconbitmap('icon1.ico')
	option.geometry("300x350+500+150")
	option.resizable(False,False)
	background_image=tk.PhotoImage(file = "bg1.gif")
	background_label = tk.Label(option, image=background_image)
	background_label.place(x=0, y=0, relwidth=1, relheight=1)
		
	def passs():
		pass
	
	option.protocol("WM_DELETE_WINDOW",passs)
	
	def t_voters(*args):
		curx1.execute("select * from voter")
		data = curx1.fetchall()
		if(len(data)>0):
			option.withdraw()
			from rem_voters import T_Vo
			T_Vo()
			option.deiconify()
		else:
			tk.messagebox.showerror("Can't open","add voter in electoral list")
	
	def exit():
		option.quit()		
	
	def elec_list():
		option.withdraw()
		from voter_list import funcx1x
		funcx1x()
		option.deiconify()
	
	def r_voters():
		curx1.execute("select * from voter")
		data = curx1.fetchall()
		if(len(data)>0):	
			option.withdraw()
			from rem_voters import r_vo
			r_vo()
			option.deiconify()
		else:
				tk.messagebox.showerror("Can't open","add voter in electoral list")	
	
	def result():
		curx1.execute("select sum(vote) from party")
		data = curx1.fetchall()
		for row in data:
			x= row[0]	
		if(x!=0 and x!= None):	
			option.withdraw()
			from total_vote import func1
			func1()
			option.deiconify()
		else:
			tk.messagebox.showerror("Can't open","no one has voted yet")

	def s_voting():
		curx1.execute("select * from voter")
		data = curx1.fetchall()
		if(len(data)>0):	
			conx1.execute("update voter set voted = 0")
			try:
				conx1.commit()
			except:
				conx1.rollback()
			option.withdraw()
			from Loginfile import func1
			func1()
			option.deiconify()
			b5.config(state = "disabled")
		else:
			tk.messagebox.showerror("Can't open","add voter in electoral list")
			
	b1 = tk.Button(option,text = "Elector list",font = ('arial',10,'bold'),width = 20,bd = 5,command = elec_list).grid(sticky = "e",pady = 10,padx = 60)
	b2= tk.Button(option,text = "Today's Voters",font = ('arial',10,'bold'),width = 20,bd = 5,command = t_voters).grid( padx = 60,pady = 10,sticky = "e")
	b3 = tk.Button(option,text = "Remaining Voters",font = ('arial',10,'bold'),width = 20,bd = 5,command = r_voters).grid(sticky = "e",padx = 60,pady = 10)
	b4 = tk.Button(option,text = "Result",font = ('arial',10,'bold'),width = 20,bd = 5,command = result).grid(padx = 60,pady = 10 ,sticky = "e")	
	b5 = tk.Button(option,text = "Start Voting",font = ('arial',10,'bold'),bd = 5,width = 20,command = s_voting)
	b5.grid(padx= 60,pady = 10,sticky = "e")
	b6 = tk.Button(option,text = "Exit",font = ('arial','10','bold'),bd = 5,default="normal",width = 20,command = exit).grid(padx = 60,pady =10,sticky = "e")
	option.mainloop()
	option.destroy()
	return
	