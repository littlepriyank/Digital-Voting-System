from tkinter import *
import sqlite3
from tkinter import messagebox
import re
dbPath="C:\\VotingSystem\\voting_sys"
conx1=sqlite3.connect(dbPath)
curx1 =conx1.cursor()
qryx2 = "select * from voter"
qryx1= "delete from voter where voter_id = ?"
qryx3 = "insert into voter(voter_id,name) values(?,?)"
qryx4 = "select * from voter where voter_id = ?"
data = curx1.fetchall()
def funcx1x():
	master = Toplevel(bg = "cyan4")
	master.resizable(False,False)
		
	def passs():
		pass
	
	master.protocol("WM_DELETE_WINDOW",passs)
	def deleteall():
		curx1.execute("delete from voter")
		try:
			conx1.commit()
		except:
			conx1.rollback()
		insert()	
	def delete(listbox):

		selection = listbox.curselection()
		value = listbox.get(selection[0])
		matchobj = re.match(r'^(\d*).*',value)
		id = int(matchobj.group(1))
		curx1.execute(qryx1,[id])
		try:
			conx1.commit()
		except:
			conx1.rollback()
		insert()

	def add():
		ID = ex1.get()
		name  = ex2.get()
		match1 = re.match(r'^([a-zA-Z]){3,}$',name)
		matchobj = re.match(r'^(\d)+$',ID)
		if(matchobj and match1):
			curx1.execute(qryx4,[int(ex1.get())])
			d = curx1.fetchall()
			if(len(d)>0):
				messagebox.showerror("Inavlid","This aadhaar no. is already exist")
			else:
				curx1.execute(qryx3,[int(ex1.get()),ex2.get()])
				insert()
				try:
					conx1.commit()
				except:
					conx1.rollback()
		else:
			messagebox.showerror("wrong inputs","given input is not valid")		
	def exit():
		master.quit()
	def insert():
		listbox.delete(0,END)
		listbox.insert(END, "{:<5s}  {:>18s}".format("Id","Name") )
		curx1.execute(qryx2)
		data=curx1.fetchall()
		if(len(data)>0):
			for i  in range(len(data)):
				item = "{:<5d}  {:>15s}".format(data[i][0],data[i][1])
				listbox.insert(END, item)  
		else:
			messagebox.showerror("Empty","No ELector" )
	l1= Label(master,text = "Elector List",bg = "cyan4",font = ('arial',15,'bold')).grid(row = 0,columnspan = 3,pady = 10)
	listbox = Listbox(master, width=60,font =  'consolas')
	listbox.grid(row = 1,columnspan = 3)
	ex1 = StringVar()
	ex2 = StringVar()

	b1=Button(master,text = "Delete",width = 30,font = ('arial',10,'bold'),command = lambda: delete(listbox)).grid(row = 2,columnspan = 3,pady = 5)
	b1=Button(master,text = "Delete All",width = 30,font = ('arial',10,'bold'),command = deleteall).grid(row = 3,columnspan = 3,pady = 5)
	
	l3 = Label(master,text = "ADD ELECTOR",bg = "cyan4",font = ('arial',15,'bold')).grid(row = 4,columnspan = 3,padx = 30)
	l2 = Label(master,text = "Enter aadhaar",font = ('arial',15,'bold')).grid(row = 5,pady = 5)
	e2 = Entry(master,textvariable = ex1,width = 27,font = ('arial',10,'bold')).grid( row = 5,column  = 1,padx = 5,sticky = "w")
	
	Label(master,text = "Enter Name",font = ('arial',15,'bold')).grid(row= 6,pady = 5)
	Entry(master,textvariable = ex2,width = 27,font = ('arial',10,'bold')).grid( row = 6,column  = 1,padx = 5,sticky = "w")
	
	b2=Button(master,text = "ADD",font = ('arial',10,'bold'),width = 15,command = add).grid(row = 5,column = 2)
	b4=Button(master,text = "Exit",font = ('arial',10),width = 15,command = exit).grid(row = 6,column = 2,pady = 5)
	insert()
	master.mainloop()
	master.destroy()
	return			