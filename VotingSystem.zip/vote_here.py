import time
import tkinter as tk
import sqlite3
dbPath3="C:\\VotingSystem\\voting_sys"
con2=sqlite3.connect(dbPath3)
cur2 =con2.cursor()
qry1v="insert into party(Party,vote) values(?,?)"
qry2v='update party set vote=? where Party=?'
qry3v = "delete from party"
qry4v = "select vote from party where Party=?"
p1="Bhartiya Janta Party"
p2="Indian National Congress"
p3="Bhaujan Samaj Party"
p4="Aam Adami Party"
p5="Nationalist congress party"
p6="Communist Party of India"
p7="Samajwadi Party"
p8 = "None of the above"
def func3():
	con2.execute(qry3v)
	con2.execute(qry1v,[p1,0])
	con2.execute(qry1v,[p2,0])
	con2.execute(qry1v,[p3,0])
	con2.execute(qry1v,[p4,0])
	con2.execute(qry1v,[p5,0])
	con2.execute(qry1v,[p6,0])
	con2.execute(qry1v,[p7,0])
	con2.execute(qry1v,[p8,0])
	try:
		con2.commit()
	except:
		con2.rollback()

def func2():
	evm = tk.Toplevel()
	evm.iconbitmap('icon1.ico')
	evm.geometry("+160+80")
	evm.resizable(False,False)
	background_image=tk.PhotoImage(file = "bg2.gif")
	background_label = tk.Label(evm, image=background_image)
	background_label.place(x=0, y=0, relwidth=1, relheight=1)
	
	def passs():
		pass
	
	evm.protocol("WM_DELETE_WINDOW",passs)
	def buttonclick1():
		cur2.execute(qry4v,[p1])
		x=cur2.fetchall() 

		d=int(x[0][0])+1
		
		con2.execute(qry2v,[d,p1])
		try:
			con2.commit()
		except:
			con2.rollback()
		evm.quit()

	def buttonclick2():
		cur2.execute(qry4v,[p2]) 
		x=cur2.fetchall() 

		d=int(x[0][0])+1

		con2.execute(qry2v,[d,p2])
		try:
			con2.commit()
		except:
			con2.rollback()
		evm.quit()

	def buttonclick3():
		cur2.execute(qry4v,[p3]) 
		x=cur2.fetchall()
		d=int(x[0][0])+1

		con2.execute(qry2v,[d,p3])
		try:
			con2.commit()
		except:
			con2.rollback()
		evm.quit()

	def buttonclick4():
		cur2.execute(qry4v,[p4]) 
		x=cur2.fetchall()
		d=int(x[0][0])+1
	
		con2.execute(qry2v,[d,p4])
		try:
			con2.commit()
		except:
			con2.rollback()
		evm.quit()

	def buttonclick5():
		cur2.execute(qry4v,[p5]) 
		x=cur2.fetchall()
		d=int(x[0][0])+1
	
		con2.execute(qry2v,[d,p5])
		try:
			con2.commit()
		except:
			con2.rollback()
		evm.quit()

	def buttonclick6():
		cur2.execute(qry4v,[p6]) 
		x=cur2.fetchall()
		d=int(x[0][0])+1
	
		con2.execute(qry2v,[d,p6])
		try:
			con2.commit()
		except:
			con2.rollback()
		evm.quit()

	def buttonclick7():
		cur2.execute(qry4v,[p7]) 
		x=cur2.fetchall()
		d=int(x[0][0])+1
	
		con2.execute(qry2v,[d,p7])
		try:
			con2.commit()
		except:
			con2.rollback()
		evm.quit()

	def buttonclick8():
		cur2.execute(qry4v,[p8]) 
		x=cur2.fetchall()
		d=int(x[0][0])+1
		
		con2.execute(qry2v,[d,p8])
		try:
			con2.commit()
		except:
			con2.rollback()
		evm.quit()
		
	evm.configure(background="light cyan")
	evm.title("welcome to E-voting")
	
	icon1 = tk.PhotoImage(file="bjp.gif")
	icon2 = tk.PhotoImage(file="cong.gif")
	icon3 = tk.PhotoImage(file="bsp.gif")
	icon4 = tk.PhotoImage(file="aap.gif")
	icon5 = tk.PhotoImage(file="ncp.gif")
	icon6 = tk.PhotoImage(file="cpi.gif")
	icon7 = tk.PhotoImage(file="sp.gif")
	icon8 = tk.PhotoImage(file="nota.gif")
	
	text_input=tk.StringVar()
	tk.Label(evm,text=" Welcome to E- Voting ",font=('arial',30,'bold'),bg="orchid2").grid(row=0,column=1,padx = 20)

	tk.Label(evm,text=p1,width =20,font=('arial',20,"bold")).grid(row=2,column=0,sticky="W")
	btn1=tk.Button(evm,pady = 3,bd=3,width = 200,fg="black",font=("arial",20,"bold"),compound = "right",image = icon1,text="Amit.Shah ",bg="misty rose",command=buttonclick1).grid(row=2,column=3,sticky="E")

	tk.Label(evm,text=p2,width =20,font=('arial',20,"bold")).grid(row=3,column=0,sticky="W")
	btn2=tk.Button(evm,pady = 3,bd=3,width=200,fg="black",font=("arial",20,"bold"),compound = "right",image = icon2,text=" S.Gandhi ",bg="misty rose",command=buttonclick2).grid(row=3,column=3,sticky="E")

	tk.Label(evm,text=p3,width =20,font=('arial',20,'bold')).grid(row=4,column=0,sticky="W")                                           
	btn3=tk.Button(evm,pady = 3,bd=3,width=200,fg="black",font=("arial",20,"bold"),compound = "right",image = icon3,text=" Mayawati ",bg="misty rose",command=buttonclick3).grid(row=4,column=3,sticky="E")

	tk.Label(evm,text=p4,width =20,font=('arial',20,'bold')).grid(row=5,column=0,sticky="W")                                                                                                                                 
	btn4=tk.Button(evm,pady = 3,bd=3,width=200,fg="black",font=("arial",20,"bold"),compound = "right",image = icon4,text="A.Kejriwal",bg="misty rose",command=buttonclick4).grid(row=5,column=3,sticky="E")

	tk.Label(evm,text=p5,width =20,font=('arial',20,'bold')).grid(row=6,column=0,sticky="W")
	btn5=tk.Button(evm,pady = 3,bd=3,width=200,fg="black",font=("arial",20,"bold"),compound = "right",image = icon5,text="  S.Pawar ",bg="misty rose",command=buttonclick5).grid(row=6,column=3,sticky="E")

	tk.Label(evm,text=p6,width =20,font=('arial',20,'bold')).grid(row=7,column=0,sticky="W")
	btn6=tk.Button(evm,pady = 3,bd=3,width=200,fg="black",font=("arial",20,"bold"),compound = "right",image = icon6,text="S.S.Reddy ",bg="misty rose",command=buttonclick6).grid(row=7,column=3,sticky="E")

	tk.Label(evm,text=p7,width =20,font=('arial',20,'bold')).grid(row=8,column=0,sticky="W")
	btn7=tk.Button(evm,pady = 3,bd=3,width=200,fg="black",font=("arial",20,"bold"),compound = "right",image = icon7,text=" M.S.Yadav",bg="misty rose",command=buttonclick7).grid(row=8,column=3,sticky="E")
	
	tk.Label(evm,text=p8,width =20,font=('arial',20,'bold')).grid(row=9,column=0,sticky="W")
	btn8=tk.Button(evm,pady= 3,bd=3,width=200,fg="black",font=("arial",20,"bold"),compound = "right",image = icon8,text="   NOTA",bg="misty rose",command=buttonclick8).grid(row=9,column=3,sticky="E")
	
	
	evm.mainloop()
	evm.destroy()
	return